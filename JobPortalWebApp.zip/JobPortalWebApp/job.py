from flask import Blueprint, current_app,render_template,request,redirect,flash,url_for, send_from_directory,session
from flask_login import login_required,current_user
from models import db,Job,Application,User
import os
import time
from werkzeug.utils import secure_filename
from flask_mail import Message

job_bp=Blueprint('job_bp',__name__)
@job_bp.route('/dashboard')
@login_required
def dashboard():
    jobs=Job.query.all()
    return render_template('dashboard.html',jobs=jobs)

@job_bp.route('/postjob',methods=['GET', 'POST'])
@login_required
def postjob():
    if current_user.role!='employer':
        return "Unauthorized",403
    if request.method=='POST':
        job=Job(title=request.form.get('title'),
                description=request.form.get('description'),
                salary=request.form.get('salary'),
                location=request.form.get('location'),
                company=request.form.get('company'),
                category=request.form.get('category'),
                employer_id=current_user.id)
        db.session.add(job)
        db.session.commit()
        flash("Job posted successfully!", "success")
        return redirect(url_for('job_bp.posted_jobs'))
    
    return render_template('postjob.html')

@job_bp.route('/postedjobs')
@login_required
def posted_jobs():
    jobs = Job.query.filter_by(employer_id=current_user.id).all()
    return render_template('postedjobs.html', jobs=jobs)

@job_bp.route('/employer_dashboard')
@login_required
def employer_dashboard():
    return render_template('employer_dashboard.html')

@job_bp.route('/seeker_dashboard')
@login_required
def seeker_dashboard():
    jobs = Job.query.all()  # Fetch all job listings
    return render_template('seeker_dashboard.html')

@job_bp.route('/listings', methods=['GET'])
def job_listings():
    # Fetch distinct values for dropdowns
    locations = db.session.query(Job.location).distinct().all()
    categories = db.session.query(Job.category).distinct().all()
    companies = db.session.query(Job.company).distinct().all()
    # Convert from list of tuples to a list
    locations = [loc[0] for loc in locations]
    categories = [cat[0] for cat in categories]
    companies = [comp[0] for comp in companies]
    # Apply filters
    query = Job.query
    location = request.args.get('location')
    category = request.args.get('category')
    company = request.args.get('company')
    # Query jobs based on filters
    if location:
        query = query.filter(Job.location == location)
    if category:
        query = query.filter(Job.category == category)
    if company:
        query = query.filter(Job.company == company)
    jobs = query.all()
    return render_template('job_list.html', jobs=jobs, locations=locations, categories=categories, companies=companies)

@job_bp.route('/deletejob/<int:job_id>', methods=['POST'])
@login_required
def delete_job(job_id):
    job = Job.query.filter_by(id=job_id, employer_id=current_user.id).first()
    if job:
        db.session.delete(job)
        db.session.commit()
        flash("Job deleted successfully!", "success")
    else:
        flash("Job not found or unauthorized!", "danger")
    
    return redirect(url_for('job_bp.posted_jobs'))

@job_bp.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    user = User.query.get(user_id)

    if user:
        # Delete all jobs posted by this user before deleting the user
        jobs = Job.query.filter_by(employer_id=user.id).all()
        for job in jobs:
            db.session.delete(job)

        db.session.delete(user)
        db.session.commit()
        flash('User and all their jobs deleted successfully!', 'success')
    else:
        flash('User not found!', 'danger')

    return redirect(url_for('job_bp.admin_dashboard'))
@job_bp.route('/apply/<int:job_id>',methods=['GET', 'POST'])
@login_required
def applyjob(job_id):
    from app import mail
    job = Job.query.get_or_404(job_id)  # Fetch job details
    employer = User.query.get(job.employer_id)  # Fetch employer details

    if request.method == 'POST':
        # Ensure a resume file is uploaded
        if 'resume' not in request.files or request.files['resume'].filename == '':
            flash('Resume file is required.', 'danger')
            return redirect(url_for('job_bp.applyjob', job_id=job_id))

        resume = request.files['resume']
        cover_letter = request.files.get('cover_letter')  # Optional cover letter

        # Generate a unique filename for the resume
        resume_filename = f"resume_{current_user.id}_{job_id}_{int(time.time())}.pdf"
        resume_data = resume.read()  # Read file as binary data

        # Process cover letter (if uploaded)
        cover_letter_data = None
        cover_letter_filename = None
        if cover_letter and cover_letter.filename:
            cover_letter_filename = f"cover_{current_user.id}_{job_id}_{int(time.time())}.pdf"
            cover_letter_data = cover_letter.read()  # Read file as binary data

        # Store application in the database
        application = Application(
            job_id=job_id,
            user_id=current_user.id,
            resume=resume_data,  # Store resume as BLOB
            resume_filename=resume_filename,
            cover_letter=cover_letter_data,  # Store cover letter as BLOB (optional)
            cover_letter_filename=cover_letter_filename
        )
        db.session.add(application)
        db.session.commit()

        # Send email to employer with resume and cover letter attached
        if employer:
            msg = Message(
                subject=f'New Job Application for {job.title}',
                sender=employer.email,  # Employer email as sender
                recipients=[employer.email]  # Send to employer
            )
            msg.body = f"""
            Dear {employer.username},

            {current_user.username} has applied for the job "{job.title}".
            
            Resume: {resume_filename}
            Cover Letter: {cover_letter_filename if cover_letter_filename else "Not Provided"}

            Please check your employer dashboard for details.
            """
            # Attach resume
            msg.attach(resume_filename, "application/pdf", resume_data)
            # Attach cover letter (if available)
            if cover_letter_data:
                msg.attach(cover_letter_filename, "application/pdf", cover_letter_data)

            mail.send(msg)

        flash('Application submitted successfully!', 'success')
        return redirect(url_for('job_bp.job_listings'))

    return render_template('applyjob.html', job=job)

@job_bp.route('/admin_dashboard')
@login_required
def admin_dashboard():
    if session.get('role') != 'admin':
        flash("Access denied!", "danger")
        return redirect(url_for('auth.login'))
    users = User.query.filter(User.id != current_user.id).all()    
    jobs = Job.query.all()  # Fetch all jobs
    return render_template('admin_dashboard.html', users=users, jobs=jobs)

@job_bp.route('/admin_delete_job/<int:job_id>', methods=['POST'])
@login_required
def admin_delete_job(job_id):
    job = Job.query.get(job_id)
    if job:
        # Delete all applications for this job first
        Application.query.filter_by(job_id=job.id).delete()
        
        # Now delete the job
        db.session.delete(job)
        db.session.commit()
        flash("Job and its applications deleted successfully!", "success")
    else:
        flash("Job not found!", "danger")

    return redirect(url_for('job_bp.admin_dashboard'))

