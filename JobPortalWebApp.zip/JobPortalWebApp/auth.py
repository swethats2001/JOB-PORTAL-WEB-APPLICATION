from flask import Blueprint,render_template,redirect,url_for,request,flash,session
from werkzeug.security import generate_password_hash,check_password_hash
from flask_login import login_user,logout_user,login_required
from models import db,User

auth=Blueprint('auth',__name__)

@auth.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        username=request.form.get('username')
        email=request.form.get('email')
        password = request.form.get('password')
        role=request.form.get('role')
        if not username or not email or not password:
            flash("All fields are required!", "danger")
            return redirect(url_for('auth.register'))
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Email already exists. Please use a different email.', 'danger')
            return redirect(url_for('auth.register'))
        hashed_pwd=generate_password_hash(password,method='pbkdf2:sha256')
        new_user=User(username=username,email=email,password=hashed_pwd,role=role)
        db.session.add(new_user)
        db.session.commit()
        flash('Account created successfully','success')
        return redirect(url_for('auth.login'))
    
    return render_template('register.html')

@auth.route('/login',methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()

        if user is None:
            flash("User not found! Please register first.", "danger")
            print("DEBUG: User not found")
            return redirect(url_for('auth.login'))

        if not check_password_hash(user.password, password):
            flash("Incorrect password! Try again.", "danger")
            print("DEBUG: Incorrect password")
            return redirect(url_for('auth.login'))

        # Successful login
        login_user(user)  # Ensure user is authenticated
        session.permanent = True  # Ensure session persists
        session['user_id'] = user.id
        session['role'] = user.role
        flash("Login successful!", "success")
        print(f"DEBUG: User {user.email} logged in successfully! ID: {session.get('user_id')}, Role: {session.get('role')}")
        if user.role == 'admin':
            return redirect(url_for('job_bp.admin_dashboard'))  # Admin Dashboard
        elif user.role == 'employer':
            return redirect(url_for('job_bp.employer_dashboard'))  # Employee Dashboard
        else:
            return redirect(url_for('job_bp.job_listings')) 

    return render_template('login.html')


@auth.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    flash('You have logged out','info')
    return redirect(url_for('auth.login'))


