import os

class Config:
    SECRET_KEY = '8eb97444adb8492473b380030d05d2cf'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///database.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
