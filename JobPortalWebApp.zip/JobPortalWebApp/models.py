from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
# from app import db  # Import `db` from `app.py`, DO NOT create a new instance

db=SQLAlchemy()

class User(db.Model,UserMixin):
    id=db.Column(db.Integer,primary_key=True)
    username=db.Column(db.String(50),unique=True,nullable=False)
    email=db.Column(db.String(120),unique=True,nullable=False)
    password=db.Column(db.String(100),nullable=False)
    role=db.Column(db.String(20),nullable=False,default="job_seeker")

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    salary = db.Column(db.Integer)
    location = db.Column(db.String(100))
    company = db.Column(db.String(100))
    category = db.Column(db.String(100), nullable=False) 
    employer_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    resume = db.Column(db.LargeBinary, nullable=False)  # Changed from String to BLOB
    resume_filename = db.Column(db.String(255), nullable=False)  # Store filename
    cover_letter = db.Column(db.LargeBinary, nullable=True)  # Optional cover letter
    cover_letter_filename = db.Column(db.String(255), nullable=True)  # Optional filename

    job = db.relationship('Job', backref='applications')
    user = db.relationship('User', backref='applications')
